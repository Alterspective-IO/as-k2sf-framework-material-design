
export interface IAttachedCustomControl {
  elementId: string;
  element: HTMLElement;
}
