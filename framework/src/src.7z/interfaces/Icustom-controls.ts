import { CustomControlTargetSmartObject } from "../Models/SmartObject/customControlTargets";
import { IControl } from "./IControl";
import { IFramework } from "./IFramework";

export interface ICustomControls {
    as: IFramework;
    dependantViewName: string;
    processCustomControlsPromise: any;
    customControlTargets: IControl;
    customControlTargetsArray: any;
    processCustomContols(): any;
    processCustomControl(customControlTarget: CustomControlTargetSmartObject): any;
}
