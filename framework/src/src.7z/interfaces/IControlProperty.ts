
export interface IControlProperty {
  name: string;
  value: string;
}
