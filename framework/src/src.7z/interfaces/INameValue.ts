
export interface INameValue {
  name: string;
  value: string;
}

export interface INameValueAny {
  name: string;
  value: any;
}
