import { IControllerDefinition } from "./AGIControllerDefinition";

export interface IField extends IControllerDefinition.Field { }
