import { IDictionary } from "./IDictionary";


export interface IExtensions {
  loadedExtensions: IDictionary;
}
