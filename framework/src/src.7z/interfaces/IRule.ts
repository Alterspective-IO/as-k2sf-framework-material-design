import { IViewInstance } from "./IViewInstance";
import { IView } from "./IView";
import { IRuleDefinition } from "./AGIControllerDefinition";



export interface IRule extends IRuleDefinition.Event {
  get parentView(): IView | undefined; get parentViewInstance(): IViewInstance | undefined; execute(): any;

}
