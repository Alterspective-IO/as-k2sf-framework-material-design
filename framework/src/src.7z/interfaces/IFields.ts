import { IField } from "./IField";



export interface IFields extends Array<IField> { }
