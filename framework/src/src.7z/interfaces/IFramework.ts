import iframeResizer from "iframe-resizer";
import { ICollections } from "./ICollections";
import { IControl } from "./IControl";
import { ICustomControls } from "./Icustom-controls";
import { IDependantControls } from "./IDependantControls";
import { IExtensions } from "./IExtensions";
import { IForm } from "./IForm";
import { INotifications } from "./INotifications";
import { ISearch } from "./ISearch";
import { ISettings } from "./ISettings";
import { ISupportingObjects } from "./ISupportingObjects";
import { IUser } from "./IUser";
import { IView } from "./IView";
import { IViewInstance } from "./IViewInstance";


export interface IFramework {
  
  supportingObjects: ISupportingObjects;
  form?: IForm;
  collections: ICollections;
  window: Window;
  initializePromise?: Promise<IFramework>;
  attachedEventsEnabled: boolean;
  extensions?: IExtensions;
  customControls?: ICustomControls;
  search: ISearch;
  notifications: INotifications;
  toastr: any;
  settings: ISettings;
  user: IUser;
  iFrameResizer: typeof iframeResizer.iframeResizer;
  //codeEditor : typeof MonacoEditor.editor.create
  //codeEditorCss : any
  cachedScript(url: string, options: any): Promise<any>;
  initialize(): Promise<IFramework>;
  initializePostFrameworkLoadModules(): void;
  getControlsById(id: string, viewInstanceName?: string): IControl[];
  getViewInstanceByName(name: string): IViewInstance;
  getViewInstancesByNameContains(name: string): IViewInstance[];

  getViewByName(name: string): IView;
  getViewsByNameContains(name: string): IView[];

  //Control Search Helpers
  getControlsByName(name: string, viewInstanceName?: string): IControl[];
  getControlsByNameContains(name: string, viewInstanceName?: string): IControl[];
  getControlsByType(type: string, viewInstanceName?: string): IControl[];
  getControlsByTypeContains(type: string, viewInstanceName?: string): IControl[];
  validateDependantControls(dependantControls: IDependantControls): void;
  validateDependantControl(name: string, viewOrViewInstanceName: string): IControl;
}
