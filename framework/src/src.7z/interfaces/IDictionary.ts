
export interface IDictionary {
  [index: string]: string;
}
