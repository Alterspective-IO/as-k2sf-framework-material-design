import { IView } from "./IView";



export interface IViews extends Array<IView> { }
