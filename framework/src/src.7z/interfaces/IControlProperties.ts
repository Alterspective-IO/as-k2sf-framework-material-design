import { IControlProperty } from "./IControlProperty";



export interface IControlProperties extends Array<IControlProperty> { }
