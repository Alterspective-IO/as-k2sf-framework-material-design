import { IViewInstance } from "./IViewInstance";



export interface IViewInstances extends Array<IViewInstance> { }
