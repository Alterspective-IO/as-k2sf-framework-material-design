// import { isForOfStatement } from "typescript";
// import { CustomControlSetting } from "./customControl";


// interface SpecialMethods<T>
// {
//     get: T
    
// }

// interface ISetting
// {
//     Something:string
// }



// interface ISpecialSetting extends ISetting
// {
//     Another:string
//     Setting: string | ISetting
// }


// interface ICustomControl<T extends ISetting>
// {
//     Name: string
//     Description: string
//     Settings: T[]
   
// }

// interface ISpecialSetting extends SpecialMethods<ISpecialSetting>
// {

// }

// class CustomControlService
// {
//     //behaviour

//     static getCustomControl<T extends ICustomControl<U>,U extends ISetting>(data:string)
//     {
//         let c : ISpecialSetting

        
        
//     }


// }

// class ISpecialSettingService
// {
//     static get(data : string) : ISpecialSetting
//     {
//             ///someextrasecial
//     }
// }