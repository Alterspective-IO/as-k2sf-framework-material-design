
export interface IStyleElement {
  [key: string]: string;
}
