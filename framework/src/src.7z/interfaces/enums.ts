export enum ControlType {
  Form = "Form", Panel = "Panel", AreaItem = "AreaItem",
  Table = "Table", Cell = "Cell", Row = "Row", Column = "Column",
  Content = "Content", Label = "Label", Picture = "Picture", SFCBarcode = "SFCBarcode",
  Calendar = "Calendar", CheckBox = "CheckBox", DataLabel = "DataLabel", Hyperlink = "Hyperlink",
  ImageAnnotation = "ImageAnnotation", RadioButton = "RadioButton", RadioButtonGroup = "RadioButtonGroup", Rating = "Rating", HTMLEditor = "HTMLEditor", SharePointHyperLink = "SharePointHyperLink", Slider = "Slider", TextArea = "TextArea", TextBox = "TextBox", Button = "Button", Timer = "Timer", SaveAsPDF = "SaveAsPDF", LocationServices = "LocationServices", Worklist = "Worklist", ActivityInstances = "ActivityInstances", ActivityInstancesGrid = "ActivityInstancesGrid", ReportHeader = "ReportHeader", UserPerformance = "UserPerformance", UserPerformanceGrid = "UserPerformanceGrid", WorkflowTime = "WorkflowTime", WorkflowInstancesGrid = "WorkflowInstancesGrid", Area = "Area", View = "View", Section = "Section", Number = "Number", DropDown = "DropDown", ToolBarButton = "ToolBarButton", Date = "Date", FilePostBack = "FilePostBack", ImagePostBack = "ImagePostBack", MultiSelectCheckBox = "MultiSelectCheckBox", ListTable = "ListTable", ToolbarTable = "ToolbarTable",
  NotSet = "NotSet",
  Picker = "Picker",
  Lookup = "Lookup"
}

export enum ContainerType {
    form = "form",
    view = "view",
    control = "control",
    viewInstance = "viewInstance",
    notSet = "notSet"
}

