
export interface ISettings {
  scriptFilesUrl: string;
  notificationsServerURL: string;
}
