
export type ISmartObjectItem =
  {
    [propName: string]: string;
  } & { Joins: Array<ISmartObjectItem>; };
