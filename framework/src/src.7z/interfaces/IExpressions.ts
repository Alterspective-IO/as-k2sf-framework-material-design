import { IExpression } from "./IExpression";



export interface IExpressions extends Array<IExpression> { }
