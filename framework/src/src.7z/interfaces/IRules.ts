import { IRule } from "./IRule";



export interface IRules extends Array<IRule> { }
