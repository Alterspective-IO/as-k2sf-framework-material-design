import { IViewBasic } from "./IViewBasic";
import { IContainer } from "./IContainer";
import { IControlOfView } from "./IControlOfView";
import { IFields } from "./IFields";
import { IControls } from "./IControls";


export interface IViewInstance extends IViewBasic, IContainer {
  viewId: string;
  controls?: IControls;
  associations: { [key: string]: string; }[];
  fields: IFields;
  controlOfView: IControlOfView;
}
