import { IRule } from "./IRule";


export interface IControlRules {
  [key: string]: IRule;


}
