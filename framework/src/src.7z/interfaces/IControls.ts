import { IControl } from "./IControl";



export interface IControls extends Array<IControl> { }
