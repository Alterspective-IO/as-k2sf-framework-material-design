import { ContainerType } from "./enums";
import { IFramework } from "./IFramework";


export interface IContainer {
  containerType: ContainerType;
  name: string;
  _as: IFramework;
  formId: string;
  parent?: IContainer;
  id?: string;
  getHTMLElement(): HTMLElement;
}
