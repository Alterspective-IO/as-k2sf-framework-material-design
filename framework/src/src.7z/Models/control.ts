import { executeControl, attachHandler } from "./control-helpers";
import { IControllerDefinition } from "../interfaces/AGIControllerDefinition";
import { ControlType, ContainerType } from "../interfaces/enums";
import { IAttachedCustomControl } from "../interfaces/IAttachedCustomControl";
import { IContainer } from "../interfaces/IContainer";
import { IContentControl } from "../interfaces/IContentControl";
import { IControl } from "../interfaces/IControl";
import { IControlEvent } from "../interfaces/IControlEvent";
import { IControlEvents } from "../interfaces/IControlEvents";
import { IControlProperties } from "../interfaces/IControlProperties";
import { IControlRules } from "../interfaces/IControlRules";
import { IControls } from "../interfaces/IControls";
import { IEmittedControlEvent } from "../interfaces/IEmittedControlEvent";
import { INameValueAny } from "../interfaces/INameValue";
import { ISmartObject } from "../interfaces/SmartObjects/ISmartObject";
import { IStyleElement } from "../interfaces/IStyleElement";
import { autoMapAttributesToProperties } from "../processors";
import { BaseArray, BaseItem } from "./base";
import { ControlProperties } from "./properties";
import { implementControlExtensions } from "./html-helpers";





export class Controls extends BaseArray<Control, IControllerDefinition.Control, IContainer> implements IControls {
    constructor(control: IControllerDefinition.Control[] | undefined, parent: IContainer) {
        //let p = new PerformanceSession("Controls.Constructor()")
        super(Control, control, parent);
        //p.finish()
    }
}


export class Control extends BaseItem<IControllerDefinition.Control, IContainer> implements IControl {
    
    constructor(control?: IControllerDefinition.Control, parent?: IContainer)
    constructor(control: IControllerDefinition.Control, parent: IContainer) {
        // let p = new PerformanceSession("Control.Constructor()")
        super(control!, parent!)

        this.controlTemplate = undefined
        this.dataType = undefined
        this.expressionId = undefined
        this.fieldId = undefined
        this.panelId = undefined
        this.type = ControlType.NotSet
        this.styles = {}
        this.events = new ControlEvents(this)
        this._rules = {}

        if(!control) return;

        autoMapAttributesToProperties(control, this)

        this.containerType = ContainerType.control

        //TODO:
        this.properties = new ControlProperties(control!.properties, this)
        this.id = control!.id

        this.extensions = new ControlExtensions()
        implementControlExtensions(this)

        //add this control to all controls
        this._as!.collections?.viewInstanceControls?.push(this)


        //  p.finish()

    }
    styles: IStyleElement;
    type: ControlType;
    properties?: IControlProperties;
    override id? :string;
    dataType: IControllerDefinition.Type | undefined;
    panelId: string | undefined;
    fieldId: string | undefined;
    expressionId?: string | undefined;
    controlTemplate?: IControllerDefinition.ControlTemplate | undefined;

    attachedEvents = new Array<any>()
    events: IControlEvents

    attachedCustomControl?:IAttachedCustomControl
    extensions?: ControlExtensions

    

    //on demand
    private _rules: IControlRules
    private _rulesInitialized: boolean = false
    public get rules(): IControlRules {
        if (this._rulesInitialized == false) {
            this._rules = {}
            let controlRules = this._as!.collections.rules.filter(r => r.sourceId == this.id)
            controlRules.forEach(r => {
                
                this._rules[r.name] = r
            })
            this._rulesInitialized = true;
        }
        return this._rules
    }


    public get value(): string | undefined {
        return executeControl(this, "GetValue",this._as);
        
    }

    public set value(value: string | undefined) {
       
        executeControl(this, "SetValue",this._as, value);
    }

    execute(method: string, optionalPropertyName: string, optionalValue: string) {
        executeControl(this, method,this._as, optionalValue, optionalPropertyName);
       
    }

    getControlPropertyValue(propertyName: string) {
        
        var functionName = "GetProperty";
        return executeControl(this, functionName, this._as,null, propertyName);
    }

    setControlPropertyValue(propertyName: string, propertyValue: string) {
        var functionName = "SetProperty";
        return executeControl(this, functionName, this._as,propertyValue, propertyName);
    }

    getPropertyValue(property: string) {
        this.getControlPropertyValue(property);
    };

    setPropertyValue(property: string, value: any) {
        this.setControlPropertyValue(property, value);
    };

    setControlVisibility(IsVisible: boolean) {
        this.setControlPropertyValue("IsVisible", `${IsVisible}`);
    };

    get smartobject() : ISmartObject 
    {
        let retValue: ISmartObject = { exists: false };
        
  
        var hash =
          this._as!.window.ViewHiddenHash[
            this.parent?.parent?.id + "_" + this.parent!.id
          ];
        if (hash) {
          let smartObjectItems = hash.filter( (data:any) => {
            return data.controlid == this.id;
          });
          if (smartObjectItems.length > 0) {
            retValue.exists = true;
            retValue.name = smartObjectItems[0].name;
            retValue.join = smartObjectItems[0].join;
            retValue.items = [];
            smartObjectItems.forEach(function (item:any) {
              let newItem : any = {}//item.fields;
  
              Object.keys(item.fields).forEach(key=>{
                newItem[key] = item.fields[key].value
              })
  
              
              //if (!newItem.asLineItemCounter) {
                //newItem["asLineItemCounter"] = item.counter;
              //}
              if (item.joins) {
                newItem.Joins = [];
                item.joins.forEach(function (join:any) {
                  //var newJoin = join.fields;
                  let newJoin:any = {}

                  Object.keys(join.fields).forEach(jkey=>{
                    newJoin[jkey] = join.fields[jkey].value
                  })

                  newJoin.JoinedSmartObjectName = join.name;
  
                  newItem.Joins.push(newJoin);
                });
              }
              retValue.items?.push(newItem);
            });
          }
        }
        return retValue;
      };


    asContentControl() : IContentControl
    {

        let retValue = new ContentControl();

        Object.assign(retValue,this)

        return retValue;
    }

}

export class ContentControl extends Control implements IContentControl
{
    private _autoResize : boolean = false

    constructor(){
        super()
    }

    iframeResizedCallback = (e:iframeResizer.IFrameResizedData) =>
    {
        let parentDiv = this.getHTMLElement()
        $(parentDiv).height(e.height)
        console.log(e)
    }

    public showSomething(something: string) : string
    {
        return something + "_______"
    }

    public set autoResize(value: boolean) {
        console.log("🚀 ~ file: control.ts ~ line 195 ~ setautoResize ~ value", value)
        this._autoResize = value;
        if(value==true)
        {
            let parentDiv = this.getHTMLElement()
            let containedIframe = $("iframe",parentDiv)[0] as HTMLIFrameElement
            this._as!.iFrameResizer({ log: false, heightCalculationMethod:"documentElementOffset" , checkOrigin: false, resizedCallback:this.iframeResizedCallback }, containedIframe);
        }
    }

    public get autoResize() : boolean {
        return this._autoResize;
    }


}

export class EmittedControlEvent {

    control: Control
    eventName: string
    controlEvent: string
    controlEventState: string | null
    type: string
    functionToExecute: Function
    enabled: boolean
    additional?: any
    id?: string
    deleted: boolean

    constructor(
        control: Control,
        name: string,
        event: string,
        state: string | null,
        type: string,
        func: Function,
        enabled: boolean,
        additional?: any,
        optionalId?: string
    ) {

        this.control = control;
        this.controlEvent = event;
        this.functionToExecute = func;
        this.controlEventState = state;
        this.eventName = name;
        this.type = type;
        this.enabled = enabled;
        this.additional = additional;
        this.id = optionalId; //generate ID for this event.
        this.deleted = false
    }


    remove() {
        console.log(this);
        this.deleted = true;
        if (this.type === "jquery") {
            // $(this.this.HTMLElement()).unbind(this.controlEvent);
            //Dont need to remove as even checking will make sure disabled donet fire as well as make sure we dont add more events to native event hander than we need
        } else {
            //
        }
    };
}
export class ControlEvent implements IControlEvent {


    constructor(public name: string,
        public controlEvent: string,
        public controlEventState: string,
        public type: string,
        public applyTo: string,
        public parentControl: Control
    ) { }

    removeEvent(event: any) : void {
        event.remove();
    };

    addEvent(
        func: Function,
        optionalAdditional?: any,
        optionalId?: string
    ) : IEmittedControlEvent {


        let newControlEvent = new EmittedControlEvent(
            this.parentControl,
            this.name,
            this.controlEvent,
            this.controlEventState,
            this.type,
            func,
            true,
            optionalAdditional,
            optionalId
        );

        if (
            this.parentControl.attachedEvents.filter(function (e) {
                return e.eventName == newControlEvent.eventName;
            }).length == 0
        ) {
            if (this.type === "smartform") {
                attachHandler(
                    this.parentControl,
                    this.controlEvent,
                    this.controlEventState,
                    (controlInfo: any, valueInfo: any, value: any) => {
                        this.parentControl.attachedEvents.filter((ctrEvent: any) => {
                            return (
                                ctrEvent.controlEvent === this.controlEvent &&
                                ctrEvent.controlEventState ===
                                this.controlEventState &&
                                ctrEvent.type === "smartform"
                            );
                        }).forEach(function (ctrEvent) {
                            if (typeof ctrEvent.functionToExecute === "function") {
                                if (ctrEvent.deleted == false)
                                    if (ctrEvent.enabled == true) {
                                        ctrEvent.functionToExecute(ctrEvent);
                                    }
                            }
                        });
                    }
                );
            }

            if (this.type === "jquery") {
                ($(this.parentControl.getHTMLElement()) as any)[this.controlEvent]((
                    jqueryEvent: any
                ) => {
                    if (this.parentControl.attachedEvents != null) {
                        this.parentControl.attachedEvents.filter((ctrEvent) => {
                            var f = ctrEvent;
                            return (
                                ctrEvent.controlEvent === this.controlEvent &&
                                ctrEvent.type === "jquery"
                            );
                        }).forEach(function (ctrEvent) {
                            if (typeof ctrEvent.functionToExecute === "function") {
                                try {
                                    if (ctrEvent.deleted == false)
                                        if (ctrEvent.enabled == true)
                                            ctrEvent.functionToExecute(ctrEvent, jqueryEvent);
                                } catch (err: any) {
                                    console.warn(
                                        "Error in attached event function: " + err.message
                                    );
                                }
                            }
                        });
                    }
                });
            }
        }
        this.parentControl.attachedEvents.push(newControlEvent);
        return newControlEvent;
    };

}
export class ControlExtensions {
    [name: string]: any
    properties: Array<string> = [];

    constructor() {
    }

    addExtension(nameValue: INameValueAny) {
        this[nameValue.name] = nameValue.value
        this.properties.push(nameValue.name)
    }

}

class ControlEvents implements IControlEvents {

    constructor(public parentControl: Control) { }

    smartformEventChanged = new ControlEvent("smartformEventChanged",
        "OnChange",
        "after",
        "smartform",
        "", this.parentControl)

    smartformEventPopulated = new ControlEvent("smartformEventPopulated",
        "OnSetItemsCompleted",
        "before",
        "smartform",
        "",
        this.parentControl)

    smartformEventClicked = new ControlEvent("smartFormEventClicked",
        "OnClick",
        "after",
        "smartform",
        "", this.parentControl)

    smartFormEventClick = new ControlEvent("smartformEventClick",
        "OnClick",
        "before",
        "smartform",
        "", this.parentControl)
    elementClick = new ControlEvent("elementClick",
        "click",
        '',
        "jquery",
        "", this.parentControl)
    elementMouseMove = new ControlEvent("elementMouseMove",
        "mousemove",
        '',
        "jquery",
        "", this.parentControl)
    elementMouseEnter = new ControlEvent("elementMouseEnter",
        "mouseenter",
        '',
        "jquery",
        "", this.parentControl)
    elementMouseLeave = new ControlEvent("elementMouseLeave",
        "mouseleave",
        '',
        "jquery",
        "", this.parentControl)
    elementHover = new ControlEvent("elementHover",
        "hover",
        '',
        "jquery", "", this.parentControl)


}
