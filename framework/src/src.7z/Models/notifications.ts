import {EventEmitter} from "events"
import { io } from "socket.io-client"
import { Framework } from "./framework";
import { INotificationMessage } from "../interfaces/INotificationMessage";
import { INotifications } from "../interfaces/INotifications";
import { IEmissions } from "../interfaces/IEmissions";
import { IExtendedSocket } from "../interfaces/IExtendedSocket";


export class Notifications extends EventEmitter  implements INotifications {

    private URL: string = "http://localhost:3200";
    public socket: IExtendedSocket// io(URL, { autoConnect: true });
    private _untypedOn = this.on
    private _untypedEmit = this.emit
    public override on = <K extends keyof IEmissions>(event: K, listener: IEmissions[K]): this => this._untypedOn(event, listener)
    public override emit = <K extends keyof IEmissions>(event: K, ...args: Parameters<IEmissions[K]>): boolean => this._untypedEmit(event, ...args)
  
    
    constructor(public as: Framework) {
        super()
        this.URL = as.settings.notificationsServerURL
        this.socket = io(this.URL, { autoConnect: true }) as IExtendedSocket;
        this.socket.auth = { user: as.user };
        this.attachDefaultEventReceivers()
    }

    attachDefaultEventReceivers() {
        // // client-side
        this.socket.on("connect",() => {
            console.log(`notifications connected(${this.socket.id})`); // x8WIv7-mJelg7on_ALbx
            this.emit("connect",this.socket) 
        });

        this.socket.on("disconnect", () => {
            console.log(`notifications disconnect(${this.socket.id})`);
            this.emit("disconnect", this.socket)
            this.socket.connect()
        });

        this.socket.io.on("error", (error) => {
            console.log(`notifications error(${this.socket.id})`);
            this.emit("disconnect",this.socket)
        });

        this.socket.on("NotificationMessage", (message) => {
            console.log(`NotificationMessage`);
            this.emit("notificationMessageReceived",message)
        });

        this.socket.on("connect_error", (err) => {
            console.log(`notifications connect_error(${err.message}`);
            if (err.message === "invalid username") {
                console.error(err)
            }
        });       
    }


    joinRoom(roomName:string)
    {
        this.socket.emit("join",roomName)
    }

    leaveRoom(roomName:string)
    {
        this.socket.emit("leave",roomName)
    }

    sendNotificationMessage(notification: INotificationMessage) {
        this.socket.emit("NotificationMessage",notification)
    }
}
