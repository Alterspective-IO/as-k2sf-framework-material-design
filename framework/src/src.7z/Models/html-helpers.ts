import { ContainerType, ControlType } from "../interfaces/enums";
import { IContainer } from "../interfaces/IContainer";
import { Control } from "./control";
import { ViewInstance } from "./viewInstances";



export function getContainerElement(obj: IContainer): HTMLElement {
  let anyOfObj = obj as any
  var elementId = anyOfObj.id;
  switch (obj.containerType) {
    case ContainerType.control:
      elementId = getControlElementId(obj as Control)
      break;

    case ContainerType.viewInstance:
      elementId = getViewInstanceElementId(obj as ViewInstance)
      break;
    default:
      console.error(`Not Implemented - getContainerElementID [${obj.containerType}]`)
      break;
  }
  return elementId
}

//Gets the view instance div - the actual div is two levels up so we navigate up and 
function getViewInstanceElementId(viewInstance: ViewInstance): HTMLElement {
  let retElementId
  retElementId = viewInstance.mainTable;
  var viewDiv = $(`#${viewInstance.mainTable}`).parent().parent()
  retElementId = `${viewInstance.instanceId}_view`;
  viewDiv.attr("asId", retElementId)
  return viewDiv[0]
}

function getControlElementId(control: Control): HTMLElement | undefined {
//var p = $("input.input-control[type=checkbox]").checkbox()
  //p[1].CheckBoxBehavior._tabIndex

  let elementId = control.id
  let retValue: HTMLElement | undefined

  switch (control.type) {
    case ControlType.Form:
      elementId = elementId!.split("_")[1];
      retValue = $(`#${elementId}`)[0]
      break;

    case ControlType.Picker:
      //need to append _Primary to a picker
      elementId = elementId + "_Primary"
      retValue = $(`#${elementId}`)[0]
      break;

      case ControlType.Calendar:
      elementId = elementId + "_TextBox"
      retValue = $(`#${elementId}`)[0]
      break;
    case ControlType.TextArea:
      elementId = elementId + "_TextArea"
      retValue = $(`#${elementId}`)[0]
      break;
    case ControlType.CheckBox:
      elementId = elementId + "_CheckBox"
      retValue = $(`#${elementId}`).parent()[0]
      break;

    case ControlType.MultiSelectCheckBox:
      elementId = elementId + "_MultiSelectPanel"
      retValue = $(`#${elementId}`)[0]
      break;


    case ControlType.DropDown:
      elementId = elementId;
      retValue = $(`#${elementId}`)[0]
      break;
    case ControlType.Lookup:
      elementId = elementId + "_LookupTextBox"
      retValue = $(`#${elementId}`)[0]
      break;
    case ControlType.Rating:
      elementId = elementId + "_Div";
      retValue = $(`#${elementId}`)[0]
      break;

    case ControlType.ImagePostBack:
      elementId = elementId + "_ImagePanel"
      retValue = $(`#${elementId}`)[0]
      break;
    case ControlType.Table:
      elementId = elementId + "_Table"
      retValue = $(`#${elementId}`)[0]
      break
    case ControlType.FilePostBack:
      elementId = elementId + "_FilePanel"
      retValue = $(`#${elementId}`)[0]
      break
    case ControlType.Cell:
      elementId = elementId?.split("_")[1];
      retValue = $(`#${elementId}`, control.parent.getHTMLElement())[0]
      break
    case ControlType.View:

      retValue = $(`#${elementId}`)[0]
      if (!retValue) {

        retValue = $(`#_${elementId?.split("_")[1]}`)[0] //When its the only view on a view. ie runtime/view/ and not runtime/form/
      }
      break
    case ControlType.Row:
    case ControlType.Section:
      return undefined //controls type ignored
    default:

      elementId = elementId;
      retValue = $(`#${elementId}`)[0]
      break;
  }

  console.log(`Getting HTML Element for control type ${control.type}`)
  console.log(retValue)

  if (retValue) {
    return retValue
  }

  if ($(`#${elementId}` + "_" + control.type)[0]) {
    return $(`#${elementId}` + "_" + control.type)[0]
  }

  console.warn(`Could not find the HTML element for the control [${control.name}] of type [${control.type}] `)

  return undefined

}

export function implementControlExtensions(control: Control) {

  if (!control.extensions) return
  let cx = control.extensions

  switch (control.type) {
    case ControlType.DropDown:

      cx.addExtension({ name: "dropDownItemsElementId", value: control.id });
      cx.addExtension({
        name: "dropDownItemsElement", value: function () {
          return $("#" + cx.dropDownItemsElementId)[0]
        }
      })
      break;
    case ControlType.AreaItem:
      break;
    case ControlType.Picker:
      break;
    case ControlType.TextArea:
      cx.addExtension({ name: "SFCTextArea", value: window.SFCTextArea._getInstance(control.id) });
      break;
    case ControlType.ImagePostBack:
      var FileThumbnailHTMLElementID = control.id + "_FileThumbnail";

      cx.addExtension({
        name: "FileThumbnail", value:
        {
          "HTMLElementID": FileThumbnailHTMLElementID,
          "HTMLElement": function () {
            return $("#" + FileThumbnailHTMLElementID)[0];
          },
          "Url": function () {
            return cx.FileThumbnail.HTMLElement().src;
          }
        }
      })
      break;
    case ControlType.Table:
      break;
  }
}