import { v4 as uuidv4 } from 'uuid';

let performanceSessions: Array<PerformanceSession> = new Array

export function getAllPerformanceSession() : Array<PerformanceSession> 
{
    return performanceSessions
}

export class PerformanceSession {
    name: string
    time: Date
    start: number
    end?: number
    id: string
    counter: number = 0
    static counter: number = 0

    constructor(name?: string) {
        if(!name)
        {
            name="unknown";
        }
        this.name = name
        this.id = uuidv4()
        this.time = new Date(Date.now())
        this.start = performance.now()
        this.counter = PerformanceSession.counter++

        console.log(`%c Executing:${this.addSpaces()} [${this.counter}] ${this.name}`, 'background: #222; color: green')
        performanceSessions.push(this)
        
    }

    finish()
    {
       
        this.end = performance.now();    
        const inSeconds = (this.end - this.start)
        console.info(`%c Completed:${this.addSpaces()} [${this.counter}] ${this.name} in ${inSeconds} milliseconds`, 'background: #222; color: #bada55')
    }

    addSpaces() : string
    {
        let retValue = ''
        for (let index = 0; index < this.counter; index++) {
            retValue += " "
            
        }

        return retValue
    }
    
    

}

