/*

    Alterspective Framework Module

    This modules is responsible for loading of the framework:
    1. Converting the K2 XML into json objects 
    2. Cleaning the json objects into a more user friendly representation 
    3. Adding event hooks to controls
    4. Adding control capabilities

*/


import { parseString } from 'xml2js'
import * as _ from "lodash"
import { addScript, isDefined } from "./framework.utils"
import { PerformanceSession } from "./framework.performance"
import { camelCase, reject } from "lodash"

import * as tt from "toastr"
import iframeResizer from 'iframe-resizer'
import { IControllerDefinition } from '../interfaces/AGIControllerDefinition'
import { ControlType } from '../interfaces/enums'
import { ICollections } from '../interfaces/ICollections'
import { IControl } from '../interfaces/IControl'
import { ICustomControls } from '../interfaces/Icustom-controls'
import { IDependantControls } from '../interfaces/IDependantControls'
import { IExtensions } from '../interfaces/IExtensions'
import { IFramework } from '../interfaces/IFramework'
import { INotifications } from '../interfaces/INotifications'
import { IRule } from '../interfaces/IRule'
import { IUser } from '../interfaces/IUser'
import { IView } from '../interfaces/IView'
import { IViewInstance } from '../interfaces/IViewInstance'
import { Search } from './search'
import { Control } from './control'
import { attachToControlEvents } from './control-helpers'
import { CustomControls } from './custom-controls'
import { Extensions } from './extensions'
import { Form } from './form'
import { Notifications } from './notifications'
import { Rules } from './rule'
import { Settings } from './Settings'
import { User } from './User'
import { ViewInstance } from './viewInstances'


//Add CSS Dependencies
const ToastrCss = require("toastr/build/toastr.css")
const iFrameResizerContentsWindow = require("iframe-resizer/js/iframeResizer.contentWindow")
//const CodeEditorCss = require("monaco-editor/min/vs/editor/editor.main.css")

//constants
const thisFileName = "as-framework.ts"



export class Framework implements IFramework {

    supportingObjects: SupportingObjects
    form?: Form
    collections: ICollections
    search: Search
    window: Window
    initializePromise?: Promise<IFramework>
    attachedEventsEnabled: boolean = true;
    extensions?: IExtensions
    customControls?:ICustomControls
    toastr = tt
    settings: Settings;
    notifications: INotifications
    user: IUser
    iFrameResizer: typeof iframeResizer
    //codeEditor : typeof MonacoEditor.editor.create
    //codeEditorCss = CodeEditorCss;
    toasrCss = ToastrCss
   // developerMode: DeveloperMode
    // monacoEditor = MonacoEditor
    //monacoEnvironment =  MonacoEnvironment


    constructor(windowInstance: Window, scriptFilesUrl: string, notificationsServerURL: string) {
        let p = new PerformanceSession("AS.Constructor()")
        this.applyMaterialIcons()
        this.user = new User()
        this.settings = new Settings(scriptFilesUrl, notificationsServerURL)
        this.window = windowInstance
        this.supportingObjects = new SupportingObjects();
        this.collections = new Collections()
        this.search = new Search(this)
        this.notifications = new Notifications(this)
      //  this.developerMode = new DeveloperMode(this)
        //this.initializePromise = this.initialize()
        windowInstance.as = this

        this.iFrameResizer = iframeResizer
        //this.codeEditor = MonacoEditor.editor.create

        addScript(iFrameResizerContentsWindow, null, window.document)

        // this.codeEditor(document.body,{
        //     language: 'javascript'
        // });

    }


    inIframe() {
        try {
            return window.self !== window.top;
        } catch (e) {
            return true;
        }
    }

    private managePopupOpenedRunCounter = 0;
    private managePopupOpened() //this is run only once.
    {

        let targetNode = $(".popupManager")[0]
        let config = { attributes: false, childList: true, subtree: true };
        if (targetNode) {
            if (this.managePopupOpenedRunCounter == 0) {
                this.managePopupOpenedRunCounter++
                const PopupObserver = new MutationObserver(entries => {
                    console.log("--------")
                    console.log(entries)
                    console.log("--------")

                    if ($(targetNode).children().length == 0) {
                        $(targetNode).height("")
                        $("body").height("")
                    }

                });

                PopupObserver.observe(targetNode, config);
            }

        }


    }

    attachListener() {
        this.window.addEventListener("message", (event) => {
            // Do we trust the sender of this message?  (might be
            // different from what we originally opened, for example).
            console.log('-------- Framework Event Received -----------');
            console.log(event);

            if (event.data) {

                if (event.data == "sfrtFormReady") {
                    this.managePopupOpened();
                }

                if (event.data.type) {
                    if (event.data.type == "ASBodyHeightChanged") {
                        if (event.source) {
                            //this.window.postMessage(event); //bubble up
                            let sourceDocument = (event.source as any).document;
                            if (sourceDocument.defaultView) {
                                if (sourceDocument.defaultView.parent) {
                                    console.log("TODO: Check - Is this in the same site:")
                                    console.log(sourceDocument.defaultView.parent);
                                    let parentDocument: any
                                    try {
                                        parentDocument = sourceDocument.defaultView.parent.document;
                                    } catch (error) {
                                        console.log("Parent is not accessible")
                                    }

                                    if (parentDocument) {
                                        let popupManagerDocumentBody = sourceDocument.defaultView.parent.document.body;
                                        let popupManagerDiv = parentDocument.getElementsByClassName("popupManager")[0];
                                        let popupDialogDiv = $(parentDocument.getElementsByClassName("popupManager")[0]).children()[1];


                                        (this.window as any).popupDiv = popupManagerDiv;

                                        let popupDocumentBodyHeight = $(parentDocument).height();
                                        let diff = event.data.height - (popupDocumentBodyHeight || 0);

                                        if (diff > 0) {


                                            $(popupManagerDiv).height(event.data.height + diff);
                                            $(popupDialogDiv).height(event.data.height + diff);
                                            $(popupManagerDocumentBody).height(event.data.height + diff);
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }



            // event.source is popup
            // event.data is "hi there yourself!  the secret response is: rheeeeet!"
        }, false);

    }


    attachPopupResizer() {
        const resizeObserver = new ResizeObserver(entries => {
            console.log('Body height changed:', entries[0].target.clientHeight)
            let x = $(".popupManager .popup.dialog")

            console.log(entries[0]);
            console.log(entries[0].target.ownerDocument.defaultView);

            entries[0].target.ownerDocument.defaultView?.postMessage
                ({
                    "type": "ASBodyHeightChanged",
                    "height": entries[0].target.clientHeight
                })




        });
        resizeObserver.observe(this.window.document.body);





    }

    async cachedScript(url: string, options: any): Promise<any> {
        options = $.extend(options || {}, {
            dataType: "script",
            cache: true,
            url: url,
        });
        return jQuery.ajax(options);
    };

    async initialize(): Promise<IFramework> {
        let p = new PerformanceSession("AS.Initialize()")

        return this.processK2SmartFormsXML(this.window).then(() => {
            let m = new PerformanceSession("AS.processK2SmartFormsXML")

            this.form = new Form(this)
            attachToControlEvents(this)
            this.collections.rules = new Rules(this.supportingObjects.__runtimeEventsDefinition_Object, this)
            this.initializePostFrameworkLoadModules();

            this.attachPopupResizer();
            this.attachListener();

            this.checkForContentControlResizeRequest();
          //  this.developerMode.initialise()

            m.finish();
            p.finish()
            return this
        })
    }
    initializePostFrameworkLoadModules() {
        this.customControls = new CustomControls(this)
        this.extensions = new Extensions(this)
    }


    private async processK2SmartFormsXML(windowInstance: Window): Promise<void> {
        let p = new PerformanceSession("AS.validateFramework()")
        return new Promise(async (resolve, reject) => {
            let promiseArray = new Array<Promise<any>>()
            promiseArray.push(this.processXML(windowInstance.__runtimeControllersDefinition, "__runtimeControllersDefinition"))
            promiseArray.push(this.processXML(windowInstance.__runtimeParametersDefinition, "__runtimeParametersDefinition"))
            promiseArray.push(this.processXML(windowInstance.__runtimeSessionDetails, "__runtimeSessionDetails"))
            promiseArray.push(this.processXML(windowInstance.__runtimeEventsDefinition, "__runtimeEventsDefinition"))
            await Promise.all(promiseArray); //wait for all to complete and output performance
            p.finish()
            resolve()
        })
    }
    async processXML(xml: string, name: string) {
        if (!isDefined(xml)) {
            console.warn(`processXML: xml is not defined`)
            return;
        }
        let p = new PerformanceSession(`processXML(${name})`)

        //Convert XML to Document
        let p0 = new PerformanceSession(`DOMParser().parseFromString(${name})`);
        try {
            (this.supportingObjects as any)[name + '_Document'] = new DOMParser().parseFromString(xml, "text/xml");
        }
        catch (err) {
            console.error(`Failed processing XML for : ${name} : ${err}`)
            //throw err
        }
        p0.finish()

        let p1 = new PerformanceSession(`parseString(${name})`)
        parseString(xml, {
            tagNameProcessors: [camelCase],
            attrNameProcessors: [camelCase],
            explicitArray: false,
            explicitRoot: true,
            mergeAttrs: true

        }, (err, result) => {
            if (err) {
                console.warn(err);
            }

            if (result) {
                //tt.success(`${name} XML Processes`);
                (this.supportingObjects as any)[name + '_Object'] = result;
                // (this.supportingObjects as any)[name + '_JSON'] = JSON.stringify(result);
            }
            else {
                console.warn(`Processing XML ${name} resulted in NULL`)
            }
            p1.finish()
        })

        p.finish()
    }
    getControlsById(id: string, viewInstanceName?: string): IControl[] {
        return this.collections.viewInstanceControls.filter(c => c.id === id && (viewInstanceName ?? c.parent?.name === viewInstanceName, true))
    }

    //View Search Helpers
    getViewInstanceByName(name: string): IViewInstance {
        return genericSearchPropEqual(this.collections.viewInstances, "name", name)[0] as IViewInstance
    }
    getViewInstancesByNameContains(name: string): IViewInstance[] {
        return genericSearchPropContains(this.collections.viewInstances, "name", name) as IViewInstance[]
    }

    getViewByName(name: string): IView {
        return genericSearchPropEqual(this.collections.views, "name", name)[0]
    }
    getViewsByNameContains(name: string): IView[] {
        return genericSearchPropContains(this.collections.views, "name", name)
    }

    //Control Search Helpers
    getControlsByName(name: string, viewInstanceName?: string) { return genericSearchPropEqual(this.collections.viewInstanceControls, "name", name, viewInstanceName) }
    getControlsByNameContains(name: string, viewInstanceName?: string) { return genericSearchPropContains(this.collections.viewInstanceControls, "name", name, viewInstanceName) }
    getControlsByType(type: string, viewInstanceName?: string) { return genericSearchPropEqual(this.collections.viewInstanceControls, "type", type, viewInstanceName) }
    getControlsByTypeContains(type: string, viewInstanceName?: string) { return genericSearchPropContains(this.collections.viewInstanceControls, "type", type, viewInstanceName) }
    validateDependantControls(dependantControls: IDependantControls) {
        try {
            //check that all required controls are present
            for (const [key, value] of Object.entries(dependantControls)) {
                value.control = this.validateDependantControl(value.name, value.viewOrViewInstanceName)
            }

        } catch (err) {
            console.error(err)
            throw err;
        }
    };

    validateDependantControl(name: string, viewOrViewInstanceName: string): IControl {

        let retControl: Control



        let dependantViewInstance
        if (viewOrViewInstanceName) {
            dependantViewInstance = (this.collections.views.find(v => v.viewName == viewOrViewInstanceName)?.viewInstances[0] as ViewInstance)
            if (!dependantViewInstance)
                dependantViewInstance = this.collections.viewInstances.find(v => v.name == viewOrViewInstanceName) as ViewInstance
        }

        if (!dependantViewInstance)
            throw `A dependant view or viewInstance [${viewOrViewInstanceName}] was not found `;

        retControl = this.getControlsByName(name, dependantViewInstance.name)[0]
        if (!retControl) {
            console.warn(`aA dependant control [${name}] was not found on view/viewInstance [${viewOrViewInstanceName}]`)
            //fordev
            //debugger;
            console.warn(`View/viewInstance [${viewOrViewInstanceName}] has the following controls:`)
            _.sortBy(dependantViewInstance.controls, c => c.containerType).forEach(c => {
                console.log(`%c ${c.type} - %c ${c.name}`,'background: #222; color: green','background: #222; color:  #bada55')
            })
            throw `aA dependant control [${name}] was not found on view/viewInstance [${viewOrViewInstanceName}]`;
        }

        return retControl

    };

    // validateDependantControlT<T extends IControl>(name: string, viewOrViewInstanceName: string): T {

    //     let retControl: T



    //     let dependantViewInstance
    //     if (viewOrViewInstanceName) {
    //         dependantViewInstance = (this.collections.views.find(v => v.viewName == viewOrViewInstanceName)?.viewInstances[0] as ViewInstance)
    //         if (!dependantViewInstance)
    //             dependantViewInstance = this.collections.viewInstances.find(v => v.name == viewOrViewInstanceName) as ViewInstance
    //     }

    //     if (!dependantViewInstance)
    //         throw `Dependant view or viewInstance [${viewOrViewInstanceName}] not found `;

    //     retControl = this.getControlsByName(name, dependantViewInstance.name)[0]
    //     if (!retControl)
    //         throw `A dependant control [${name}] not found on view/viewInstance [${viewOrViewInstanceName}]`;

    //     return retControl

    // };

    applyMaterialIcons() {
        $("head").append(
            $('<link rel="stylesheet" type="text/css" />').attr(
                "href",
                "https://fonts.googleapis.com/icon?family=Material+Icons"
            )[0]
        );

    }

    checkForContentControlResizeRequest() {
        this.collections.viewInstanceControls.filter(c => c.type == ControlType.Content).forEach(control => {
            let contentsControl = control.asContentControl();
            contentsControl.events.smartformEventChanged.addEvent(() => {
                contentsControl!.autoResize = true;
            })
        })
    }


}

class Collections implements ICollections {

    viewInstanceControls = new Array<Control>()
    viewInstances = new Array<IViewInstance>()
    views = new Array<IView>()
    rules = new Array<IRule>()

    //TODO AllRules = new Array<Rule>()


}

export function genericSearchPropEqual(array: Array<any>, prop: string, value: string, viewInstanceName?: string): any[] {
    return array.filter((c: any) => {
        if (c[prop]) {
            if (viewInstanceName)
                return c[prop] == value && c.parent.name == viewInstanceName
            else
                return c[prop] == value
        }
    })
}

export function genericSearchPropContains(array: Array<any>, prop: string, value: string, viewInstanceName?: string): any[] {
    return array.filter((c: any) => {
        if (c[prop]) {
            if (viewInstanceName)
                return c[prop].contains(value) && c.parent.name == viewInstanceName
            else
                return c[prop].contains(value)
        }
    })
}


class SupportingObjects {
    __runtimeControllersDefinition_Object?: IControllerDefinition.ControllerDefinition
    __runtimeEventsDefinition_Object?: any
    __runtimeEventsDefinition_Document?: Document
    __runtimeSessionDetails_Document?: Document
    __runtimeSessionDetails_Object?: any
    __runtimeParametersDefinition_Document?: Document
    //  __runtimeParametersDefinition_Object?: ParameterDefinitions.ParameterDefinitions
    constructor() { }
}



