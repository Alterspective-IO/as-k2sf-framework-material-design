import { Framework } from "./framework";
import { IFramework } from "../interfaces/IFramework";
import { Control} from "./control";


   export  function attachToControlEvents(as:Framework) {
      //debugger;
      //For reloading
      if (typeof as.window.originalHandleEvent != "undefined") {
        as.window.handleEvent = as.window.originalHandleEvent;
        as.window.originalHandleEvent = undefined;
      }
      if (typeof as.window.originalExecuteControlFunction != "undefined") {
        as.window.executeControlFunction = as.window.originalExecuteControlFunction;
        as.window.originalExecuteControlFunction = undefined;
      }

      if (typeof as.window.originalHandleEvent === "undefined") {
        as.window.originalHandleEvent = as.window.handleEvent;
        as.window.handleEvent = function (
          sourceId : string,
          sourceType: string,
          eventName : string,
          r:any,
          u:any,
          f:any,
          e:any,
          o:any,
          s:any,
          h:any,
          c:any,
          l:any
        ) {
  
          let control = as.collections?.viewInstanceControls?.find((c:any)=>c.id==sourceId)

          if (sourceType == "Control" && control !== null) {
            

            getControlHandlers()
              .filter(handler=> {
                return (
                  control?.id === handler.control.id &&
                  handler.event === eventName &&
                  handler.when === "before"
                );
              })
              .forEach(function (item) {
                item.handler(getControlInfo(sourceId,as), null, null);
              });
          }
          var value = as.window.originalHandleEvent(
            sourceId,
            sourceType,
            eventName,
            r,
            u,
            f,
            e,
            o,
            s,
            h,
            c,
            l
          );
          if (value != null) {
            value.then(function () {
              if (sourceType == "Control" && control !== null) {
                getControlHandlers()
                  .filter(function (handler) {
                    return (
                      control?.id === handler.control.id &&
                      handler.event === eventName &&
                      handler.when === "after"
                    );
                  })
                  .forEach(function (item) {
                    item.handler(getControlInfo(sourceId,as), null, null);
                  });
              }
            });
          }
          return value;
        };
      }
      
      if (typeof as.window.originalExecuteControlFunction === "undefined") {
        as.window.originalExecuteControlFunction = as.window.executeControlFunction;
        as.window.executeControlFunction = function (
          controlInfo:any,
          eventName:string,
          valueInfo:any
        ) {
          if (as.attachedEventsEnabled==true) {
            getControlHandlers()
              .filter(function (handler) {
                var name;
                if (typeof controlInfo.getAttribute != "undefined") {
                  name = controlInfo.getAttribute("Name");
                } else {
                  name = controlInfo.Name;
                }

                return (
                  handler.control.name === name &&
                  handler.event === eventName &&
                  handler.when === "before"
                );
              })
              .forEach(function (item) {
                item.handler(controlInfo, valueInfo, null);
                
              });
          }
          var value = as.window.originalExecuteControlFunction(
            controlInfo,
            eventName,
            valueInfo
          );
          if (as.attachedEventsEnabled==true) {
            getControlHandlers()
              .filter(function (handler) {
                var name;
                if (typeof controlInfo.getAttribute != "undefined") {
                  name = controlInfo.getAttribute("Name");
                } else {
                  name = controlInfo.Name;
                }

                return (
                  handler.control.name === name &&
                  handler.event === eventName &&
                  handler.when === "after"
                );
              })
              .forEach(function (item) {
                item.handler(controlInfo, valueInfo, value);
              });
          }
          return value;
        };
      }
    }

  


    function getControlInfo(controlId: string,as:IFramework) {
      return new as.window.PopulateObject(null, null, controlId);
    }

    let controlHandlers = new Array<{
      control:     Control,
      controlId?: string,
      event: string,
      handler: Function,
      when: string,
    }>();
    function getControlHandlers() {
      return controlHandlers;
    }

    export function attachHandler (control: Control, event: string, when: string, handler: Function) {
      controlHandlers.push({
        control: control,
        controlId: control.id,
        event: event,
        handler: handler,
        when: when,
      });
    }

    
    

  

  export function executeControl(
    control : Control,
    method: string,
    as:IFramework,
    optionalValue?: any,
    optionalPropertyName?: any    
  ) {
    var executionResult = null; // the result of executing the control

    //use K2 function to populate the function parameter
    var functionInputConfig = new as.window.PopulateObject(
      null,
      optionalValue,
      control.id
    );

    //if there are any optionals apply them into the function input parameter
    if (optionalPropertyName != null)
      functionInputConfig.property = optionalPropertyName;   

    try {
      //Build the controlHash - K2 functions are all stored in a array
      var controlHashName = (control.id + "_" + method) as any
      //Get the function to execute
      let functionToExecute = as.window.executeControlFunctionHash[controlHashName] ;
      //in cases with autogenerated forms the function could be empty, if se we need to set it manually
      if (typeof functionToExecute == "undefined") {
        
        // var u = $.grep<any>(control.properties!, function (x) {
        //   return x.name === method;
        // })[0].value;

       

        //get The Control Property execute value
        let propertyValue = control.properties!.find(c=>c.name===method)?.value


        if (propertyValue != null) {
          //now get the function and set it in the control hash collection for next time
          functionToExecute = as.window.evalFunction(propertyValue);
          as.window.executeControlFunctionHash[controlHashName] = functionToExecute;
        } else as.window.executeControlFunctionHash[controlHashName] = -1;
      }
   
      if(typeof functionToExecute == "function")
      {
        executionResult = functionToExecute(functionInputConfig)
      }
      else
      {
        // what to do if not a function
        console.warn(`${control.name} of ${control.parent.name} - ${method} is not a function `)
        //functionToExecute === -1 && (q.functionExists = !1)
      }

    } catch (err) {
     
      console.warn(`${control.name} of ${control.parent.name} - ${method} caused an error `)
      console.error(err)
    }
    return executionResult;
  }