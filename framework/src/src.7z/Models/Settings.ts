import { ISettings } from "../interfaces/ISettings";


export class Settings implements ISettings {
    constructor(scriptFilesUrl: string, notificationsServerURL: string) {
        this.notificationsServerURL = notificationsServerURL;
        this.scriptFilesUrl = scriptFilesUrl;
    }
    scriptFilesUrl: string;
    notificationsServerURL: string;

}
