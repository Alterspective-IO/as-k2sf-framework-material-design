import { ViewInstance } from "./viewInstances";


// export function addSmartObjectToControl(control : Control) {
//     control.smartObject = function () {
//       let retValue: ISmartObject = { exists: false };
//       retValue.parent = control

//       var hash =
//         control._as.window.ViewHiddenHash[
//           control.parent?.parent?.id + "_" + control.parent.id
//         ];
//       if (hash) {
//         let smartObjectItems = hash.filter(function (data:any) {
//           return data.controlid == control.id;
//         });
//         if (smartObjectItems.length > 0) {
//           retValue.exists = true;
//           retValue.name = smartObjectItems[0].name;
//           retValue.join = smartObjectItems[0].join;
//           retValue.items = [];
//           smartObjectItems.forEach(function (item:any) {
//             let newItem : any = {}//item.fields;

//             Object.keys(item.fields).forEach(key=>{
//               newItem[key] = item.fields[key].value
//             })

            
//             //if (!newItem.asLineItemCounter) {
//               //newItem["asLineItemCounter"] = item.counter;
//             //}
//             if (item.joins) {
//               newItem.Joins = [];
//               item.joins.forEach(function (join:any) {
//                 var newJoin = join.fields;
//                 newJoin.JoinedSmartObjectName = join.name;

//                 newItem.Joins.push(newJoin);
//               });
//             }
//             retValue.items?.push(newItem);
//           });
//         }
//       }
//       return retValue;
//     };
//   }



  //TODO: Decide if we going to implement..
export function addSmartObjectsToViewInstance(viewInstance: ViewInstance ) {
    
    
    // let smartObjectHiddenViewHashId = viewInstance.parent.id + "_" + viewInstance.id;
    // let retSmartObject : ISmartObject= 
    // {
    //     exists:false
    // }

    // viewInstance.smartObject = function () {
    
    //     let smartObjectItems = viewInstance._as.window.ViewHiddenHash[smartObjectHiddenViewHashId]
    //   if (isDefined(smartObjectItems)) {
       

    //     if (smartObjectItems.length > 0) {
    //       retSmartObject.exists = true;
    //       retSmartObject["name"] = smartObjectItems[0].name;
    //       retSmartObject["join"] = smartObjectItems[0].join;
    //       retSmartObject["items"] = [];
    //       smartObjectItems.forEach(function (item:any) {
    //         let newItem : any = item.fields
    //       ;
    //        // if (!newItem.ASLineItemCounter) {
    //          // newItem["ASLineItemCounter"] = item.counter;
    //         //}
    //         if (item.joins) {
    //           newItem.Joins = [];
    //           item.joins.forEach(function (join:any) {
    //             var newJoin = join.fields;
    //             newJoin.JoinedSmartObjectName = join.name;
    //             newItem.Joins.push(newJoin);
    //           });
    //         }
    //         retSmartObject.items?.push(newItem);
    //       });
    //     }
    //   }
    //   return retSmartObject;
    // };
 
  }
