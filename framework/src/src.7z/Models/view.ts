import * as _ from "lodash"
import { PerformanceSession } from "./framework.performance";
import { autoMapAttributesToProperties } from "../processors";
import { BaseArray, BaseItem } from "./base";
import { IViews } from "../interfaces/IViews";
import { IView } from "../interfaces/IView";
import { ViewInstances } from "./viewInstances";
import { ContainerType } from "../interfaces/enums";
import { IControllerDefinition } from "../interfaces/AGIControllerDefinition";
import { IContainer } from "../interfaces/IContainer";
import { IViewInstance } from "../interfaces/IViewInstance";

export class Views extends BaseArray<View, IControllerDefinition.Controller, IContainer> implements IViews {
    constructor(controllers: IControllerDefinition.Controller[] | undefined, parent: IContainer) {
        let p = new PerformanceSession("Views.Constructor()")    
        super(View, _.uniqBy(controllers, 'id'), parent);
        p.finish()
    }
}

export class View extends BaseItem<IControllerDefinition.Controller, IContainer> implements IView {
    constructor(view: IControllerDefinition.Controller, parent: IContainer) {
        let p = new PerformanceSession(`View.Constructor(${view.viewName})`)
        super(view, parent)

        this.viewName = undefined
        this.typeView= undefined
        this.id = undefined
        this.contextType = undefined

        autoMapAttributesToProperties(view, this)

        this.name = this.viewName || ""
        if (this.typeView == '') this.containerType = ContainerType.form
        else this.containerType = ContainerType.view

        this.viewInstances = [];

        //populate view Instances
        if (this.id) {
            let p1 = new PerformanceSession(`viewInstancesArray(${view.viewName})`)
            let viewInstancesArray = this._as?.search?.definitions_getViewInstancesByViewId(this.id)
            p1.finish()
            this.viewInstances = new ViewInstances(viewInstancesArray, this)
        }
        parent._as.collections.views.push(this)
        p.finish()
    }
    isEnabled?: string | undefined;
  

    viewInstances: IViewInstance[];
    viewName: string | undefined;
    typeView?: IControllerDefinition.TypeView | undefined ;
    override id?: string | undefined ;
    contextType?: IControllerDefinition.TType | undefined ;

    
}
