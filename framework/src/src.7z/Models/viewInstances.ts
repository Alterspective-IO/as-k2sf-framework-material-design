
import { autoMapAttributesToProperties } from "../processors";
import { BaseArray, BaseItem } from "./base";
import { Controls } from "./control";
import { ContainerType } from "../interfaces/enums";
import { IView } from "../interfaces/IView";
import { addSmartObjectsToViewInstance } from "./smartObject";
import { IControllerDefinition } from "../interfaces/AGIControllerDefinition";
import { IControlRules } from "../interfaces/IControlRules";
import { IControls } from "../interfaces/IControls";
import { IFields } from "../interfaces/IFields";
import { INameValue } from "../interfaces/INameValue";
import { IStyleElement } from "../interfaces/IStyleElement";
import { IControlOfView } from "../interfaces/IControlOfView";
import { IViewInstance } from "../interfaces/IViewInstance";
import { IViewInstances } from "../interfaces/IViewInstances";


export class ViewInstances extends BaseArray<ViewInstance, IControllerDefinition.Controller, IView> implements IViewInstances {
    constructor(controllers: IControllerDefinition.Controller[] | undefined, parent: IView) {
      //  let p = new PerformanceSession("ViewInstances.Constructor()")
        super(ViewInstance, controllers, parent);
      //  p.finish()
    }
 
}
export class ViewInstance extends BaseItem<IControllerDefinition.Controller,IView> implements IViewInstance {



    constructor(view: IControllerDefinition.Controller, parent: IView) {
        //let p = new PerformanceSession("ViewInstance.Constructor()")
        super(view, parent)
        this.contextId = undefined
        this.contextType = undefined
        this.dataSourceId = undefined
       
        this.instanceId = undefined
        this.isEnabled = undefined
        this.mainTable = undefined
        this.controlOfView = new controlOfView(undefined);
        this._rules={}

        autoMapAttributesToProperties(view, this)
        this.name = "";
        this.containerType = ContainerType.viewInstance;

        if (this.instanceId) {
            let controlOfViewObj = this._as?.search?.definitions_getViewInstanceControl("00000000-0000-0000-0000-000000000000", this.instanceId)
            this.id = controlOfViewObj?.id
            this.controlOfView = new controlOfView(controlOfViewObj)
            this.name = this.controlOfView.name || ''
        }

        // this.associations = view.associations?.association //TODO

        this.id = view.instanceId || ''
        this.viewId = view.id || ''

        this.associations = []
        this.fields = [];

        this.controls = new Controls(view.controls?.control, this)
        this.viewInstanceManipulations = new ViewInstanceManipulations(this)


        //add this view instance to all view instances
        this._as.collections?.viewInstances?.push(this)

        addSmartObjectsToViewInstance(this)
       // p.finish();

        // this.properties = validateArray<IControllerDefinition.FluffyProperty>(view.properties?.property)

    
    }

    
    controlOfView: IControlOfView;
    viewId: string;
    controls?: IControls;
    associations: { [key: string]: string; }[];
    fields: IFields;
    typeView?: IControllerDefinition.TypeView | undefined;
    instanceId?: string | undefined;
    panelId?: string | undefined;
    mainTable?: string | undefined;
    dataSourceId?: string | undefined;
    contextId?: string | undefined;
    contextType?: IControllerDefinition.TType | undefined;
    viewName?: string | undefined;
    isEnabled?: string | undefined;

    //Additional
    viewInstanceManipulations : ViewInstanceManipulations
    smartObject?: Function

      //on demand
      private _rules: IControlRules
      private _rulesInitialized: boolean = false
      public get rules() : IControlRules {
  
          if (this._rulesInitialized==false) {
              this._rules = {}
              let controlRules = this._as.collections.rules.filter(r => r.instanceId == this.instanceId)
  
              controlRules.forEach(r => {             
                  this._rules[r.name] = r
              })
              this._rulesInitialized=true;
          }
  
          return this._rules
  
      }

      
      

}

export class controlOfView implements IControlOfView {
    constructor(viewControlDetails: IControllerDefinition.Control | undefined) {

        this.dataType = viewControlDetails?.dataType;
        this.id = viewControlDetails?.id
        this.name = viewControlDetails?.name
        this.properties = undefined

        if (viewControlDetails) {
            autoMapAttributesToProperties(viewControlDetails, this)
            let controlPropertiesProperties = (viewControlDetails.properties as IControllerDefinition.PropertiesProperties).property

            if (Array.isArray(controlPropertiesProperties))
                this.properties = controlPropertiesProperties
            else {
                if(controlPropertiesProperties)
                    this.properties = [controlPropertiesProperties]              
            }
        }     
    }

    properties: INameValue[] | undefined;
    dataType: string | undefined;
    id: string | undefined;
    name: string | undefined;
    styles: IStyleElement[] | undefined;
    type: string | undefined;
   
}


export class ViewInstanceManipulations
{
    constructor(public viewInstance: ViewInstance){}
    makeMovable(width: string = "100%")
    {
       // debugger;
        $("body").append(
            $(this.viewInstance.getHTMLElement()).draggable().css('z-index', 1).css('position','absolute').css('width',width))
    }
}
