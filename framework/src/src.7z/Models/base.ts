import { getContainerElement } from "./html-helpers";
import { ContainerType } from "../interfaces/enums";
import { IContainer } from "../interfaces/IContainer";
import { IFramework } from "../interfaces/IFramework";


export class BaseArray<T, D,P extends IContainer> extends Array<T> 
{

    constructor(TCreator: { new(obj: D, parent: P): T; }, objectArray: D[] | undefined, parent: P) {
        super();
        // console.log("BaseArray : " + this.constructor.name)
        if (objectArray === undefined) objectArray = []
        if (Array.isArray(objectArray)) {
            objectArray.forEach(item => {
                let f = new TCreator(item, parent);
                //let f = new BaseItem<D>(item)
                this.push(f)
            })
        }
    }

}


export class BaseItem<D,P extends IContainer> implements IContainer {

    containerType: ContainerType = ContainerType.notSet;
    name: string = '';
    parent!: P;
    formId!: string;
    id?: string = '';
    _as!: IFramework;

    constructor(obj: D, parent: P) {        
        if (obj == undefined) {
            console.warn("obj:D is undefined!")
            return;
        }
        //autoMapAttributesToProperties(obj, this) -- doesn't work if derived class has defaults on properties
        this._as = parent._as
        this.formId = parent.formId
        this.parent = parent
            }
    getHTMLElement(): HTMLElement {
        return getContainerElement(this)
    }


}