// import { Framework } from "../framework";
// import { IDependantControl, IDependantControls } from "../interfaces/interfaces";
// import { Control } from "./control";


// export class DependantControls implements IDependantControls
// {

//     [key: string]: DependantControl;     
// }




// export class DependantControl implements IDependantControl
// {
//     constructor(name:string, viewInstanceName:string,public as:Framework)
//     {
      
//             this.name=name
//             this.viewOrViewInstanceName = viewInstanceName        
//             this.control = as.validateDependantControl(this)
        
//     }

//     name: string;
//     viewOrViewInstanceName: string;
//     control: Control;
    
// }

