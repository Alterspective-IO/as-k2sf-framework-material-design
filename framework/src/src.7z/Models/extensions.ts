import { Framework } from "./framework";
import { ExtensionConfigurationSmartObject, ExtensionSmartObject } from "./SmartObject/extentions";
import { IExtensions } from "../interfaces/IExtensions";
import { IDictionary } from "../interfaces/IDictionary";
import { IControl } from "../interfaces/IControl";
import { EmittedControlEvent } from "./control";
//import { DependantControl } from "../Models/dependantControls";

let dependantViewName = "AS.Framework.Loader"; //The view this code depends on  

class DPC {
    constructor(public _as: Framework) { }




    // extensionsToLoad =  new DependantControl("Internal - Extensions To Load", dependantViewName, this._as)
    // formName = new DependantControl("internal - Form Name", dependantViewName, this._as)
    // viewsOnForm = new DependantControl("internal - Views on Form", dependantViewName, this._as)
}



export class Extensions implements IExtensions{
    private dpc: DPC
    constructor(public _as: Framework) {
        this.dpc = new DPC(_as)

        let dependantView = _as.getViewByName(dependantViewName)
        if(!dependantView) return

        this.extensionsToLoad= this._as.validateDependantControl("Internal - Extensions To Load", dependantViewName)
        this.formName = this._as.validateDependantControl("internal - Form Name", dependantViewName)
        this.viewsOnForm =  this._as.validateDependantControl("internal - Views on Form", dependantViewName)
        this.setup();
    }

   

    extensionsToLoad! :IControl
    formName! : IControl 
    viewsOnForm! : IControl
    loadedExtensions = {} as IDictionary;

   

    setup() {
        console.log("SETUP");
        this.extensionsToLoad.events.smartformEventPopulated.addEvent((e: EmittedControlEvent) => {
            console.log("Internal - Extensions To Load - Populated");
            this.loadCode();
        });
        this.formName.value = this._as.form?.name
        this.viewsOnForm.value = this._as.collections.views.map((v) => v.name).toString()
    };

    async loadCode() {
        let so = this.extensionsToLoad.smartobject;
        if (so.exists == true) {
            so.items?.forEach((soi) => {


                let extensionConfiguration = new ExtensionConfigurationSmartObject()
                extensionConfiguration.createFromData(soi)

                let extension : ExtensionSmartObject = extensionConfiguration.Joins[0]
                if (extensionConfiguration.Enabled == "true" && extension.Enabled == "true") {
                    //only run if the extension is enabled and if its enabled on the view(s) its targeting
                    console.log(`Extension ${extensionConfiguration.Extension} is enabled on view and at extension level`)


                    if(extension.Code.length>0)
                    { 
                        //if code present then code takes priority over javascript link
                        this.addCodeExtension(extension);
                    }
                    else
                    {
                        this.addModuleViaLink(extension);
                    }
                }
                else {
                    console.warn(`Extension [${extensionConfiguration.Extension}] is not fully enabled - View enabled:[${extensionConfiguration.Enabled}]  Extension enabled:[${extensionConfiguration.Joins[0].Enabled}]`)
                }
            });
        }
    };


    private async addModuleViaLink(extension: ExtensionSmartObject) {
      
        try
        {
            //let module = await import(/* webpackIgnore */extension.Module_Url);
            let options = {
                   dataType: "script",
                  cache: true,
                   url: extension.Module_Url,
                 };
             await jQuery.ajax(options).then(() => {

             });

        }
        catch (err)
        {
            console.warn(`Error importing extension [${extension.Name}] with url [${extension.Module_Url}] - Error: [${err}]`)
            return;
        }

        if(extension.initialiseCommand.length>0)
        {
            try{
                this._as.extensions!.loadedExtensions[extension.Name]=(eval(extension.initialiseCommand))
            }
            catch(err)
            {
                console.warn(`Error calling extension [${extension.Name}] initialise command [${extension.initialiseCommand}] - Error: [${err}]`)
            }
        }

    }

    private async addCodeExtension(extension: ExtensionSmartObject) {
        let code = extension.Code.replace(
            new RegExp("{Framework Script Location}", "g"),
            this._as.settings.scriptFilesUrl
        );
 
        $("body").append(code);
    }
}